create definer = root@localhost view v_region_full_info as
select `rh`.`region_code`     AS `region_code`,
       `rh`.`region_name`     AS `region_name`,
       `rh`.`layer_level`     AS `layer_level`,
       `rh`.`parent_code`     AS `parent_code`,
       `parent`.`region_name` AS `parent_name`,
       `pr`.`region_name`     AS `province_region`
from ((`cookie_pool`.`region_hierarchy` `rh` left join `cookie_pool`.`region_hierarchy` `parent`
       on ((`rh`.`parent_code` = `parent`.`region_code`))) left join `cookie_pool`.`province_region` `pr`
      on ((`rh`.`region_code` = `pr`.`province_code`)));

-- comment on column v_region_full_info.region_code not supported: 区域代码

-- comment on column v_region_full_info.region_name not supported: 区域名称

-- comment on column v_region_full_info.layer_level not supported: 层级：1-省级，2-地级市，3-区县级，4-更细分级

-- comment on column v_region_full_info.parent_code not supported: 父级区域代码

-- comment on column v_region_full_info.parent_name not supported: 区域名称

-- comment on column v_region_full_info.province_region not supported: 所属大区（华东、华北等）

