create definer = root@localhost event cookie_auto_recovery on schedule
    every '1' MINUTE
        starts '2025-06-26 16:09:57'
    enable
    do
    UPDATE cookies
                    SET is_available = 1
                    WHERE is_available = 0
                    AND last_updated < DATE_SUB(NOW(), INTERVAL 30 MINUTE);

