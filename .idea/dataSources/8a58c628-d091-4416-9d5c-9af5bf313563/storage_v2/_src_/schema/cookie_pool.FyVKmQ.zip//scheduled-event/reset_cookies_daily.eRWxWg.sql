create definer = root@localhost event reset_cookies_daily on schedule
    every '1' DAY
        starts '2025-06-30 00:00:00'
    on completion preserve
    enable
    comment '每日00:00重置cookies表的is_available字段为1'
    do
    BEGIN
    UPDATE cookie_pool.cookies
    SET is_available = 1;

END;

