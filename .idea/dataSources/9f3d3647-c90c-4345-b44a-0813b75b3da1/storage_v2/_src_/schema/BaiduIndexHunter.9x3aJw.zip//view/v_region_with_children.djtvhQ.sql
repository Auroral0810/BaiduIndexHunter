create definer = root@localhost view v_region_with_children as
select `rc`.`parent_code`     AS `parent_code`,
       `parent`.`region_name` AS `parent_name`,
       `rc`.`child_code`      AS `child_code`,
       `child`.`region_name`  AS `child_name`,
       `child`.`layer_level`  AS `child_level`,
       `rc`.`sort_order`      AS `sort_order`
from ((`baiduindexhunter`.`region_children` `rc` join `baiduindexhunter`.`region_hierarchy` `parent`
       on ((`rc`.`parent_code` = `parent`.`region_code`))) join `baiduindexhunter`.`region_hierarchy` `child`
      on ((`rc`.`child_code` = `child`.`region_code`)))
order by `rc`.`parent_code`, `rc`.`sort_order`;

-- comment on column v_region_with_children.parent_code not supported: 父级区域代码

-- comment on column v_region_with_children.parent_name not supported: 区域名称

-- comment on column v_region_with_children.child_code not supported: 子级区域代码

-- comment on column v_region_with_children.child_name not supported: 区域名称

-- comment on column v_region_with_children.child_level not supported: 层级：1-省级，2-地级市，3-区县级，4-更细分级

-- comment on column v_region_with_children.sort_order not supported: 排序序号

