create definer = root@localhost event reset_daily on schedule
    every '1' DAY
        starts '2025-07-02 00:00:00'
    enable
    do
    UPDATE cookies
  SET is_available = 1,
      temp_ban_until = NULL
  WHERE is_permanently_banned = 0;

