create definer = root@localhost event check_temp_ban on schedule
    every '10' MINUTE
        starts '2025-07-01 20:50:57'
    enable
    do
    UPDATE cookies
  SET is_available = 1,
      temp_ban_until = NULL
  WHERE temp_ban_until < CURRENT_TIMESTAMP
    AND is_available = 0;

